from chart import ShowBoxPlot, drawResultGraphWithMamdaniMethod, ThreePaneChart, FivePaneChart


if __name__ == '__main__':

    # ShowBoxPlot()
    # ThreePaneChart.Draw()
    drawResultGraphWithMamdaniMethod("gathered_coa.txt")
    drawResultGraphWithMamdaniMethod("gathered_cog.txt")
    # FivePaneChart.Draw()
